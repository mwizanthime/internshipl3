![Exercises 3](https://user-images.githubusercontent.com/70604577/162859954-3972f3c6-081a-411f-8c82-9a2a16e7bf3f.png)

![Exercises 4](https://user-images.githubusercontent.com/70604577/162859970-dd3b1cd2-bc11-4889-8201-39d397752834.png)
